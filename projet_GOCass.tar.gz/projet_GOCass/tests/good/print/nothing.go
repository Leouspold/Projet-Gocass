package main

func main() {}

/*
== Expected program output ==
*/
