package main

import "fmt"

func main() {
	fmt.Print("a")
}

/*
== Expected program output ==
a
*/
