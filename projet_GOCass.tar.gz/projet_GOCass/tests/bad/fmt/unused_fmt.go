package main

import "fmt"

func main() {}

/*
== Expected compiler output ==
File "./tests/bad/fmt/unused_fmt.go":
error: fmt imported but not used
*/
