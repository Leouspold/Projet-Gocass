package main

func main(i int) {}

/*
== Expected compiler output ==
File "./tests/bad/main/parameters_main.go", line 3, characters 5-9:
error: func main must have no parameters and no return values
*/
