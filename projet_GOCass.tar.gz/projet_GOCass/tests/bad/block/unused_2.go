package main

func main() {
	x := 1
}

/*
== Expected compiler output ==
File "./tests/bad/block/unused_2.go", line 4, characters 1-2:
error: x declared but not used
*/
