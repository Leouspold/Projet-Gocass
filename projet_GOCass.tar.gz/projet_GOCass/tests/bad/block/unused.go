package main

func main() {
	var a int
}

/*
== Expected compiler output ==
File "./tests/bad/block/unused.go", line 4, characters 5-6:
error: a declared but not used
*/
