package main

func main() {
	var a A
}

/*
== Expected compiler output ==
File "./tests/bad/vars/unknown_type.go", line 4, characters 1-8:
error: undefined type A of variable declaration
*/
