package main

func main() {
	a = 10
}

/*
== Expected compiler output ==
File "./tests/bad/assign/unbound.go", line 4, characters 1-2:
error: unbound variable a
*/
