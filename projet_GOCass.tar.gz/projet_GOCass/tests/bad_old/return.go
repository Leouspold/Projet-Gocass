package main

func main() int {
    return 42;
}
