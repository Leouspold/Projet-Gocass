package main
type T struct { x,x int }
func main() {}
