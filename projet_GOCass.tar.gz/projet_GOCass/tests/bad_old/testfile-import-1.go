package main
func main() { fmt.Print("oups") }
